# bmp suite 1
wget -N http://entropymine.com/jason/bmpsuite/bmpsuite.zip
unzip -u -d bmpsuite bmpsuite.zip

# bmp suite 2
wget --no-check-certificate -N http://downloads.sourceforge.net/project/bmptestsuite/bmptestsuite/bmptestsuite-0.9/bmptestsuite-0.9.zip
unzip -u bmptestsuite-0.9.zip

# bmp suite 3
wget -N -P wvnet https://download.tuxfamily.org/allegro/files/bmpsuite/wvnet/test32bfv4.bmp
wget -N -P wvnet https://download.tuxfamily.org/allegro/files/bmpsuite/wvnet/test32v5.bmp
wget -N -P wvnet https://download.tuxfamily.org/allegro/files/bmpsuite/wvnet/trans.bmp

# bmp suite 4
wget -N http://entropymine.com/jason/bmpsuite/releases/bmpsuite-2.4.zip
unzip -u bmpsuite-2.4.zip
mv bmpsuite-2.4 bmpsuite2
